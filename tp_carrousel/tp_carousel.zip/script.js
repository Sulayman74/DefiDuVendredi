class Carousel {
  constructor(containerClass, nb, time) {
    this.container = document.querySelector(`.${containerClass}`);
    this.carousel = this.container.firstElementChild;
    this.images = this.carousel.children;

    this.numberOfVisibleSlides = nb;
    this.slideDelay = time;

    //dom setup
    this.container.style.overflow = "hidden";
    this.container.style.border = "2px solid black";
    this.container.style.width = "800px";
    this.container.style.margin = "auto";

    this.carousel.style.display = "flex";

    // this.carousel.style.transition = "all ease 0.4s";

    console.log(this.carousel.children);

    this.imageSizePercentage = 100 / this.numberOfVisibleSlides;
    for (const img of this.carousel.children) {
      console.log(img);
      img.style.width = `${this.imageSizePercentage}%`;
      console.log(this.imageSizePercentage);
      img.style.transition = "all ease 0.4s";
    }

    // this.carousel.style.justifyContent = "center";
    //state variables
    this.timeSlided = 0;
    this.currentTranslate = 0;
  }

  info() {
    console.log(
      this.container,
      this.carousel,
      this.images,
      this.numberOfVisibleSlides,
      this.slideDelay
    );
  }

  nextSlide() {
    const translateWidth = this.currentTranslate - this.imageSizePercentage;
    this.currentTranslate = translateWidth;
    console.log(this.currentTranslate);
    // const translateWidth = -((this.timeSlided + 1) * this.imageSizePercentage);
    this.carousel.style.transform = `translateX(${translateWidth}%)`;
    this.timeSlided++;
    // console.log(translateWidth);
  }

  previousSlide() {
    const translateWidth = this.currentTranslate + this.imageSizePercentage;
    this.currentTranslate = translateWidth;
    console.log(this.currentTranslate);
    // const translateWidth = (this.timeSlided + 1) * this.imageSizePercentage;
    this.carousel.style.transform = `translateX(${translateWidth}%)`;
    this.timeSlided++;
    // console.log(translateWidth);
  }

  run() {
    //slide interval
    const obj = this;
    setInterval(function () {
      obj.nextSlide();
    }, obj.slideDelay);
  }

  runPrevious() {
    //slide interval
    const obj = this;
    setInterval(function () {
      obj.previousSlide();
    }, obj.slideDelay);
  }
}

// let myCarousel = new Carousel("container", 3, 1000);
// myCarousel.info();

class InfiniteCarousel extends Carousel {
  constructor(containerClass, nb, time, delay = 400) {
    super(containerClass, nb, time);
    this.firstTime = true;

    let translateWidth = this.currentTranslate - this.imageSizePercentage;
    console.log({ translateWidth });
    this.carousel.style.transform = `translateX(${translateWidth}%)`;
    this.currentTranslate = translateWidth;
    this.transitionDelay = delay;
  }

  nextSlide() {
    this.carousel.style.transition = `all ease ${this.transitionDelay / 1000}s`;
    super.nextSlide();

    let obj = this;
    setTimeout(function () {
      obj.carousel.style.transition = "all ease 0s";

      //move first element to last
      obj.carousel.append(obj.carousel.firstElementChild);
      const translateWidth = obj.currentTranslate + obj.imageSizePercentage;
      obj.currentTranslate = translateWidth;
      obj.carousel.style.transform = `translateX(${translateWidth}%)`;
    }, this.transitionDelay);
  }

  previousSlide() {
    this.carousel.style.transition = `all ease ${this.transitionDelay / 1000}s`;
    super.previousSlide();

    let obj = this;
    setTimeout(function () {
      obj.carousel.style.transition = "all ease 0s";

      //move first element to last
      obj.carousel.prepend(obj.carousel.lastElementChild);
      const translateWidth = obj.currentTranslate - obj.imageSizePercentage;
      obj.currentTranslate = translateWidth;
      obj.carousel.style.transform = `translateX(${translateWidth}%)`;
    }, this.transitionDelay);
  }
}

class ButtonCarousel extends InfiniteCarousel {
  constructor(containerClass, nb, time, delay) {
    super(containerClass, nb, time, delay);

    //add buttons to move slides
    this.buttons = [];
    for (let index = 0; index < 2; index++) {
      let b = document.createElement("button");
      b.style.width = "40px";
      b.style.height = "40px";
      b.style.backgroundColor = "black";
      this.buttons.push(b);
    }

    this.buttons[0].style.clipPath = "polygon(75% 100%, 25% 50%, 75% 0)";
    this.buttons[1].style.clipPath = "polygon(25% 100%, 75% 50%, 25% 0)";

    this.container.parentElement.prepend(this.buttons[0]);
    this.container.parentElement.append(this.buttons[1]);

    //set parent of container display to flex
    this.container.parentElement.style.display = "flex";

    //set justify content to center and a gap of 20px
    this.container.parentElement.style.justifyContent = "center";
    this.container.parentElement.style.gap = "20px";

    //remove the margin auto from container
    this.container.style.margin = "0";

    //align buttons and container center
    this.container.parentElement.style.alignItems = "center";

    //add events for each buttons
    let obj = this;
    this.buttons[0].addEventListener("click", function (e) {
      obj.previousSlide();
    });

    this.buttons[1].addEventListener("click", function (e) {
      obj.nextSlide();
    });
  }
}

let myInfiniteCarousel = new ButtonCarousel("container", 3, 1000, 400);
// myInfiniteCarousel.runPrevious();

// let mySecondInfinityCarousel = new ButtonCarousel("container_2", 3, 1000);
// // mySecondInfinityCarousel.runPrevious();
