document.addEventListener("click", function (e) {
  // body
  console.log(this);
});

// function faireAction() {
//   console.log(this);
// }

// faireAction();
// console.log(this);
